#' Deliflor_opmerking_analyser
#'
#' In deze package is het vereist om de functies te volgen. Er zijn optionele functies, maar de main-path zal gevolgd moeten worden. De eerste functies zullen er voor zorgen dat de data opgeschoond wordt. De latere functies zullen uitslagen geven over de data gebaseerd op de opmerkingen en objectieve waarde.
#'
#' @docType package
#'
#' @author Bram Weve
#'
#' @name Deliflor.opmerking.analyser
NULL
