#########################################################################################################
#' objectieve_waarden_gem
#'
#' @description Maakt van een objectieve waarde het gemiddelde gebaseerd per k.nummer(sleutel) welke in uw eerste kolom moet staan.
#'
#' @param tabel data.frame(): In de eerste kolom moet u uw k.nummer(sleutel) zetten en in en de kolommen daarnaast moet in minimaal 1 kolom objectieve waarden staan
#' @param kolom numeric(): Een getal dat aangeeft welke kolom uw objectieve waarden staan.
#'
#' @return data.frame(k.nummer, objectief): Df met kolom 1 uw sleutel en kolom 2 een gemiddelde waarden per sleutel.
#' @export
objectieve_waarden_gem <- function(tabel, kolom){
  if(length(kolom) != 1 | !is.numeric(kolom)){stop("Kies een enkele kolom om te vergelijken met uw key.")}
  else{
    if(ncol(data.frame(tabel)) >= 2){
      Objective_new <- aggregate(tabel[, kolom], list(tabel[, 1]), mean)
      names(Objective_new) <- c("k.nummer", "objectief")
      class(Objective_new) <- c("data.frame", "objectieve_waarden_gem")
      return(Objective_new)
    }else{stop("Uw input moet minimaal twee kolommen lang zijn.")}
  }
}

#########################################################################################################
#' uitslag_aantal_unieke_groepen
#'
#' @description Voordat u een groep wilt maken, wilt u misschien wel eerst de groepen en hun grootte zien. Dat doet deze functie, u krijgt een output met het aantal k.nummer(sleutel) per unieke kolom/kolomen combinatie dat is aangegeven.
#'
#' @param tabel data.frame(): Df dat minimaal twee kolommen bevatten. Waarbij de eerste de kolom het k.nummer is.
#' @param kolomen c(numeric): Een getal of een serie getallen die aangeeft over welke kolom of kolommen het gaat.
#'
#' @return View(): Hier staat het aantal k.nummer(sleutel) per unieke combinatie gebaseerd op de kolom/kolommen die u als input mee gaf
#' @export
uitslag_aantal_unieke_groepen <- function(tabel, kolomen){
  if(!is.double(kolomen)){stop("Uw input kolomen mogen alleen getallen in voor komen.")}
  else{
    if(ncol(data.frame(tabel)) >= 2){
      aantallen <- data.frame(table(tabel[,kolomen]))
      aantallen <- aantallen[order(aantallen[,length(kolomen)+1], decreasing = T),]
      View(aantallen)
    }else{stop("Uw input moet minimaal twee kolommen lang zijn.")}
  }
}

#' groeper_data
#'
#' @description Deze functie scheid de groepen uit elkaar gebaseerd op de meegegeven input.
#'
#' @param tabel data.frame(): Df dat minimaal twee kolommen bevatten. Waarbij de eerste de kolom het k.nummer is.
#' @param kolomen c(numeric): Een getal of een serie getallen die aangeeft over welke kolom of kolommen het gaat
#' @param grootste numeric(): Een getal bepaalt hoeveel df er gemaakt worden. Dit omdat het aantal unieke combinatie groot kan worden indien u meerdere kolomen gebruikt.
#'
#' @return list(data.frame()): Serie van df in een list. Iedere df bestaat uit een subselectie van uw orginele df(tabel) gebaseert op de unieke filter van de aangegeven kolom(men).
#' @export
groeper_data <- function(tabel, kolomen, grootste = 5){
  if(!is.double(kolomen)){stop("Uw input kolomen mogen alleen getallen in voor komen.")}
  else{
    if(ncol(data.frame(tabel)) >= 2){
      if(ncoresx%%1==0){
        groepen <- list()
        aantallen <- data.frame(table(tabel[,kolomen]))
        aantallen <- aantallen[order(aantallen[,length(kolomen)+1], decreasing = T),]
        if(nrow(aantallen)<grootste){grootste<-nrow(aantallen)}
        for(regel in seq(from=1, to=grootste)){
          klein <- tabel[tabel[,kolomen[1]]%in%aantallen[regel,1],]
          if(length(kolomen)>1){
            for (filter in seq(from=2, to=length(kolomen))) {
              klein <- klein[klein[,kolomen[filter]]==aantallen[regel,filter],]
            }
            assign(do.call(paste, c(aantallen[regel,1:length(kolomen)], sep="_")), klein)
            groepen[[length(groepen)+1]] <- get(do.call(paste, c(aantallen[regel,1:length(kolomen)], sep="_")))
            names(groepen)[length(groepen)] <- do.call(paste, c(aantallen[regel,1:length(kolomen)], sep="_"))
          }else{
            assign(as.character(aantallen[regel,length(kolomen)]), klein)
            groepen[[length(groepen)+1]] <-get(as.character(aantallen[regel,length(kolomen)]))
            names(groepen)[length(groepen)] <- as.character(aantallen[regel,length(kolomen)])
          }
        }
        return(groepen)
      }else{stop("Het gegeven aantal voor grootste is geen heel getal.")}
    }else{stop("Uw input moet minimaal twee kolommen lang zijn.")}
  }
}

#########################################################################################################
#' diakritische_tekens_verwijderen
#'
#' @description Het verwijderen van diakritische tekens zoals aigu en grave in uw opmerkingen kolom.
#'
#' @param tabel data.frame(): Df dat minimaal twee kolommen bevatten. Waarbij de eerste de kolom het k.nummer is.
#' @param kolom numeric(1): Een getal getal dat aangeeft over welke kolom het gaat.
#'
#' @return data.frame(): Uw orginele df maar dan zonder de diakritische in uw opmerkingen kolom.
#' @export
diakritische_tekens_verwijderen <- function(tabel, kolom){
  if(length(kolom) != 1 | !is.numeric(kolom)){stop("Kies een enkele getal voor kolom om de diakritische tekens te verwijderen")}
  else{
    if(ncol(data.frame(tabel)) >= 2){
      tabel[,kolom] <- as.character(iconv(tabel[,kolom] ,"WINDOWS-1252","UTF-8"))
      return(tabel)
    }else{stop("Uw tabel input moet minimaal twee kolommen lang zijn.")}
  }
}

#' opmerking_split
#'
#' @description Het loskoppelen van de verschillende woorden in een kolom. \cr
#' Gebaseerd op de ','-komma en '.'-punt en '|'-sluisteken. Afhankelijk van uw keuze in de stijl-input zal het alle opmerkingen onder elkaar zetten zonder k.nummer
#' of allemaal onder elkaar zetten samen met het k.nummer. PAS OP: De keuze hier heeft gevolgen op volgende functies.
#'
#' @param tabel data.frame(): Df dat minimaal twee kolommen bevatten. Waarbij de eerste de kolom het k.nummer is.
#' @param kolom numeric(1): Een getal getal dat aangeeft over welke kolom het gaat.
#' @param stijl character('onbegrensd' of 'per_key')
#'
#' @return data.frame(opmerking) of data.frame(k.nummer, opmerking): Afhankelijk van input kan deze functie twee varianten returnen.
#' De eerste is een df met alle opmerkingen onder elkaar. De tweede heeft de zelfde opmerkingen, maar deze gaat gepaard met de k.nummer waarvan ze afkomstig zijn.
#' @export
opmerking_split <- function(tabel, kolom, stijl = "onbegrensd"){
  if(length(kolom) != 1 | !is.numeric(kolom)){stop("Kies een enkele getal voor uw kolom waar uw opmerkingen in staan.")}
  else{
    if(ncol(data.frame(tabel)) >= 2){
      if(stijl == "per_key"){
        Opmerkingsnijden <- stringr::str_split(tabel[,kolom], ",|\\.|\\|")
        unieke_alles <- data.frame("k.nummer" = rep(tabel[,1], sapply(Opmerkingsnijden, length)), "opmerking" = unlist(Opmerkingsnijden))
        unieke_alles[,2] <- data.frame(gsub("(^[[:space:]]+|[[:space:]]+$)", "", unieke_alles[,2]))
        unieke_alles <- data.frame(unieke_alles[unieke_alles$opmerking!="",])
        class(unieke_alles) <- c("data.frame", "opmerking_split_per_key")
        return(unieke_alles)
      }
      if(stijl == "onbegrensd"){
        Opmerkingsnijden <- stringr::str_split(tabel[,kolom], ",|\\.|\\|")
        Opmerkingvullen <- c(lapply(Opmerkingsnijden, 'length<-', max(lengths(Opmerkingsnijden))))
        Opmerkingmooi <- data.frame(t(array(unlist(Opmerkingvullen), dim = c(1,lengths(Opmerkingvullen[1])*length(Opmerkingvullen)))))
        unieke_alles <- data.frame((Opmerkingmooi$t.array.unlist.Opmerkingvullen...dim...c.1..lengths.Opmerkingvullen.1.....))
        unieke_alles["X.Opmerkingmooi.t.array.unlist.Opmerkingvullen...dim...c.1..lengths.Opmerkingvullen.1......"] <- data.frame(gsub("^$|^[[:space:]]+$", NA, unieke_alles$X.Opmerkingmooi.t.array.unlist.Opmerkingvullen...dim...c.1..lengths.Opmerkingvullen.1......))
        unieke_alles <- data.frame(unieke_alles[!is.na(unieke_alles),])
        names(unieke_alles)[1] <- "opmerking"
        unieke_alles["opmerking"] <- data.frame(gsub("(^[[:space:]]+|[[:space:]]+$)", "", unieke_alles$opmerking))
        class(unieke_alles) <- c("data.frame", "opmerking_split_onbegrensd")
        return(unieke_alles)
      }
      else{stop("De gekozen stijl bestaat niet. Dit moet of onbegrensd of per_key zijn.")}
    }else{stop("Uw tabel input moet minimaal twee kolommen lang zijn.")}
  }
}

#########################################################################################################
#' tel_aantal_per_woord
#'
#' @description Afhankelijk van de keuze in opmerking_split geeft deze functie een andere output.
#' Bij onbegrensd worden alle woorden die hetzelfde zijn bij elkaar opgeteld. Als er per_key gekozen is wordt deze telling per k.nummer gedaan.
#'
#' @param na_split data.frame(): Df output van opmerking_split.
#'
#' @return data.frame(opmerking Freq) of data.frame(k.nummer opmerking Freq): Afhankelijk van input kan deze functie twee varianten returnen.
#' Bij onbegrensd worden alle woorden die hetzelfde zijn bij elkaar opgeteld. Als er per_key gekozen is wordt deze telling per k.nummer gedaan.
#' @export
tel_aantal_per_woord <- function(na_split){
  if(length(class(na_split))==2){
    if(class(na_split)[2]=="opmerking_split_onbegrensd"){
      na_split <- data.frame(sort(table(na_split), decreasing = T))
      names(na_split) <- c("opmerking","Freq")
      class(na_split) <- c("data.frame", "tel_aantal_per_woord_totaal")
      return(na_split)
    } else if(class(na_split)[2]=="opmerking_split_per_key") {
      na_split <- data.frame(dplyr::summarise(dplyr::group_by(na_split, k.nummer, opmerking), count = dplyr::n()))
      names(na_split) <- c("k.nummer","opmerking","Freq")
      class(na_split) <- c("data.frame", "tel_aantal_per_woord_per_key")
      return(na_split)
    } else{stop("Verkeerde input, gebruik eerst de functie opmerking_split.")}
  } else{stop("Verkeerde input, gebruik eerst de functie opmerking_split.")}
}

#' uitslag_zuiverheid_vs_woordenboek
#'
#' @description Met deze funcie is het mogelijk om te kijken hoeveel van 750 meest voorkomende woorden overeenkomen met uw woordenboek.
#' Dit is nuttig om te weten omdat het woordenboek leidend zal zijn welke woorden belangrijk zijn. \cr
#' Er zal per woord 1 van de 4 opties terug geven in een nieuwe kolom. In WB 1, In WB 2, Boven ratio of NA. \cr
#' In WB 1 of 2 betekent dat het woord al in uw woordenboek staat en aangepast gaat worden. \cr
#' Bovenratio is het woord vergelijkbaar met een woord in uw woordenboek en zal veranderd worden. \cr
#' NA betekent dat het woord niet te vinden is en verwijderd zal worden. \cr \cr Ook geeft deze functie u een df met woorden die u misschien zou willen toevoegen. Deze df staat in de eerste kolom het woord waar het om gaat en in de tweede op welk woord hij lijkt.
#'
#' @param tabel data.frame(): Output van tel_aantal_per_woord of zuiver_maken_met_woordenboek als u gekozen heeft voor onbegrensd bij de opmerking_split functie.
#' @param top_woorden numeric(): Getal dat aangeeft hoeveel van de bovenste woorden zullen worden bekeken in deze functie.
#' @param ratio numeric(): Decimaal getal tussen de 0 en de 1.
#' @param woordenboek data.frame(): Uw eigen woordenboek. Deze df moet uit twee kolommen bestaan, het eerst is uw woord dat u wilt veranderen en het tweede wat dit woord zou moeten zijn.
#' Als er geen woordenboek is meegeven zal het default WB gebruikt worden.
#'
#' @return data.frame(): Df met de 750 meest gebruikte woorden met een extra kolom. Hierin zal In WB 1, In WB 2, Boven ratio of NA in komen te staan.
#' @export
uitslag_zuiverheid_vs_woordenboek <- function(tabel, top_woorden = 750, ratio = 0.81, woordenboek = NULL){
  if(length(class(tabel))==2){
    if(class(tabel)[2]=="tel_aantal_per_woord_totaal" | class(tabel)[2]=="Schoonmaak_totaal"){
      if(ratio >= 0 & ratio <= 1){
        if(is.null(woordenboek)){
          Woorden_vergelijk <- Deliflor.opmerking.analyser::sample_woordenboek
        } else {Woorden_vergelijk <- woordenboek}
        tabel <- tabel[1:top_woorden,]
        tabel[,3] <- ifelse(match(tabel[,1], Woorden_vergelijk[,2]), "In WB 2")
        tabel[is.na(tabel$V3),3] <- ifelse(match(tabel[is.na(tabel$V3),1], Woorden_vergelijk[,1]), "In WB 1")
        wrds <- tabel[,1]
        wrds2 <- Woorden_vergelijk[,2]
        combdf <- expand.grid(wrds, wrds2)
        combdf["sim"] <- RecordLinkage::levenshteinSim(as.character(combdf[,1]), as.character(combdf[,2]))
        combdf <- combdf[combdf$sim>ratio,]
        combdf <- combdf[order(combdf$sim, decreasing = T),]
        combdf <- combdf[!duplicated(combdf$Var1),]
        tabel[is.na(tabel$V3),3] <- ifelse(tabel[is.na(tabel$V3),1]%in%combdf$Var1, "Boven ratio", NA)

        woordin <- tabel[!is.na(tabel$V3),1]
        woorduit <- tabel[is.na(tabel$V3),1]
        toevoegen <- expand.grid(woorduit, woordin)
        toevoegen["sim"] <- RecordLinkage::levenshteinSim(as.character(toevoegen[,1]), as.character(toevoegen[,2]))
        toevoegen <- toevoegen[toevoegen$sim>ratio,]
        names(toevoegen) <- c("Gevonden woord","Lijkt op","ratio")
        tabel <- list(tabel)
        tabel[[""]] <- toevoegen
        return(tabel)
      } else{stop("Uw gegeven ratio is geen waarden tussen de 0 en de 1, probeer opnieuw.")}
    } else{stop("Doe eerst tel_aantal_per_woord of zuiver_maken_met_woordenboek als u gekozen heeft voor onbegrensd bij de opmerking_split functie.")}
  } else{stop("Doe eerst tel_aantal_per_woord of zuiver_maken_met_woordenboek als u gekozen heeft voor onbegrensd bij de opmerking_split functie.")}
}

#########################################################################################################
#' zuiver_maken_met_woordenboek
#'
#' @description De gegeven opmerkingen in de df zullen aan de hand van het woordenboek gezuiverd worden.
#' Alle woorden die in kolom 1 van uw woordenboek staan of lijken op de woorden in kolom 2 zullen worden aangepast naar het woord in kolom 2 van uw woordenboek.
#' Alles wat hier niet onder valt zal weg gegooit worden.
#'
#' @param tabel data.frame(): Output van tel_aantal_per_woord.
#' @param ratio numeric(): Decimaal getal tussen de 0 en de 1.
#' @param ncores numeric(1): Een getal dat aangeeft hoeveel processors u wilt gebruiken voor het verwerken van de data.
#'  Hoe hoger getal hoe sneller het berekenen gaat. Afhankelijk vanaf uw computer zit hier een maximum aan.
#' @param woordenboek data.frame(): Uw eigen woordenboek. Deze df moet uit twee kolommen bestaan, het eerst is uw woord dat u wilt veranderen en het tweede wat dit woord zou moeten zijn.
#' Als er geen woordenboek is meegeven zal het default WB gebruikt worden.
#'
#' @return data.frame(): Gelijk aan de input gebaseerd op de woorden die overeenkomen met het woordenboek.
#' @export
zuiver_maken_met_woordenboek <- function(tabel, ratio = 0.81, ncores = 1, woordenboek = NULL){
  if(length(class(tabel))==2){
    if(class(tabel)[2]=="tel_aantal_per_woord_totaal" | class(tabel)[2]=="tel_aantal_per_woord_per_key"){
      if(ratio >= 0 & ratio <= 1){
        if(ncores%%1==0){
          if(is.null(woordenboek)){
            Woorden_vervangen <- Deliflor.opmerking.analyser::sample_woordenboek
          } else {Woorden_vervangen <- woordenboek}

          names(Woorden_vervangen) <- c("woordb1", "woordb2")

          message("Grove filter, woorden vervangen met woordenboek.")
          Samenvoeg <- merge(tabel, Woorden_vervangen, by.x = "opmerking", by.y = "woordb1", all.x = T)
          Samenvoeg[,"woordb2"] <- ifelse(is.na(Samenvoeg[,"woordb2"]), as.character(Samenvoeg[,1]), as.character(Samenvoeg[,"woordb2"]))
          if(class(tabel)[2] == "tel_aantal_per_woord_per_key"){
            tabel <- Samenvoeg[,2:4]
            names(tabel) <- c("k.nummer", "Freq", "opmerking")
            wrds <- as.character(unique(tabel[,3]))
          } else if(class(tabel)[2] == "tel_aantal_per_woord_totaal"){
            tabel <- Samenvoeg[,2:3]
            names(tabel) <- c("Freq", "opmerking")
            wrds <- as.character(unique(tabel[,2]))
          }

          message("Vergelijkbare woorden vervangen gebaseerd op ratio.")
          if (Sys.info()["sysname"] == "Windows"){
            cl <- parallel::makeCluster(ncores)
            doParallel::registerDoParallel(cl)
          } else{doParallel::registerDoParallel(cores = ncores)}

          vervang <- unique(Woorden_vervangen[,2])
          `%dopar%` <- foreach::`%dopar%`
          combdf <- foreach::foreach(regel = 1:length(vervang),
                                     .combine = rbind, .inorder = F) %dopar% {
                                       combdf <- expand.grid(wrds, vervang[regel])
                                       combdf["sim"] <- RecordLinkage::levenshteinSim(as.character(combdf[,1]), as.character(combdf[,2]))
                                       combdf <- combdf[combdf$sim>ratio,]
                                       return(combdf)
                                     }
          if (Sys.info()["sysname"] == "Windows") {parallel::stopCluster(cl)}

          message("Vervangen woorden samenvoegen.")
          combdf <- combdf[order(combdf$sim, decreasing = T),]
          combdf <- combdf[!duplicated(combdf$Var1),]

          tabel <- merge(tabel, combdf, by.x = "opmerking", by.y = "Var1", all.x = T)
          tabel$Var2 <- ifelse(!is.na(tabel$Var2), as.character(tabel$Var2), as.character(tabel$opmerking))

          if(ncol(tabel)==5){
            tabel <- tabel[,c(2,4,3)]
            tabel <- aggregate(tabel[,3], tabel[,c(1,2)], sum)
            tabel <- tabel[tabel[,2]%in%Woorden_vervangen[,2],]
            names(tabel) <- c("k.nummer","opmerking","Freq")
            class(tabel) <- c("data.frame", "schoonmaak_per_key")
          } else if(ncol(tabel)==4){
            tabel <- tabel[,c(3,2)]
            tabel <- aggregate(tabel[,2], list(tabel[,1]), sum)
            tabel <- tabel[tabel[,1]%in%Woorden_vervangen[,2],]
            names(tabel) <- c("opmerking","Freq")
            class(tabel) <- c("data.frame", "Schoonmaak_totaal")
          }
          return(tabel)
        }else{stop("Het gegeven aantal processoren is geen heel getal.")}
      } else{stop("Uw gegeven ratio is geen waarden tussen de 0 en de 1, probeer opnieuw.")}
    } else{stop("Gebruik eerst de functie tel_aantal_per_woord. Voordat u deze functie gaat gebruiken.")}
  } else{stop("Gebruik eerst de functie tel_aantal_per_woord. Voordat u deze functie gaat gebruiken.")}
}

#############################################################################################################
#' uitslag_beste_ratio
#'
#' @description False positive rate: Dit is de een getal wat de betrouwbaarheid aangeeft: in dit geval is er een positief resultaat te zien terwijl de waarden in werkelijkheid negatief zijn. \cr
#' False negative rate: Dit is de een getal wat de betrouwbaarheid aangeeft: in dit geval is er een negatief resultaat te zien terwijl de waarden in werkelijkheid positief zijn. \cr
#'
#' Sensitivity: De kans dat een werkelijk positief, positief getest is. \cr
#' Specificity: De kans dat een werkelijk negatief, negatief getest is.
#'
#' @param tabel Output van tel_aantal_per_woord of zuiver_maken_met_woordenboek als u gekozen heeft voor onbegrensd bij de opmerking_split functie.
#' @param top_woorden numeric(): Getal dat aangeeft hoeveel van de bovenste woorden zullen worden bekeken in deze functie.
#' @param woordenboek Uw eigen woordenboek. Deze df moet uit twee kolommen bestaan, het eerst is uw woord dat u wilt veranderen en het tweede wat dit woord zou moeten zijn.
#' Als er geen woordenboek is meegeven zal het default WB gebruikt worden.
#'
#' @return data.frame(): Uitslag hoeveel woorden correct lijken op het woordenboek. Uitgedrukt per ratio.
#' @export
uitslag_beste_ratio <-function(tabel, top_woorden = 750, woordenboek = NULL){
  if(length(class(tabel))==2){
    if(class(tabel)[2]=="tel_aantal_per_woord_totaal" | class(tabel)[2]=="Schoonmaak_totaal"){
      if(is.null(woordenboek)){
        Woorden_vervangen <- Deliflor.opmerking.analyser::sample_woordenboek
      } else {Woorden_vervangen <- woordenboek}

      wrds <- as.character(unique(tabel[1:top_woorden,1]))
      combinaties <- t(combn(wrds, 2))
      combdf <- data.frame(t(combn(wrds, 2)))
      combdf["sim"] <- RecordLinkage::levenshteinSim(as.character(combinaties[,1]), as.character(combinaties[,2]))

      colnames(combdf) <- c("woord1", "woord2", "sim")
      combdf$order <- 1:nrow(combdf)
      combdf <- merge(combdf, Woorden_vervangen, by.x = "woord1", by.y = names(Woorden_vervangen)[1], all.x = T)
      combdf <- combdf[order(combdf$order),]
      combdf <- merge(combdf, Woorden_vervangen, by.x = "woord2", by.y = names(Woorden_vervangen)[1], all.x = T)
      combdf <- combdf[order(combdf$order),]
      combdf["eq"] <- combdf[,5] == combdf[,6]

      colnames(combdf) <- c("woord2", "woord1", "sim", "order", "con_woord1", "con_woord2", "controlle")
      percentages <- data.frame(0.7,
                                c(nrow(combdf[!is.na(combdf$controlle) & combdf$controlle==FALSE & combdf$sim>0.7,])),
                                data.frame(nrow(combdf[!is.na(combdf$controlle) & combdf$controlle==TRUE & combdf$sim<0.7,])),
                                c(nrow(combdf[!is.na(combdf$controlle) & combdf$controlle==TRUE & combdf$sim>=0.7,])),
                                data.frame(nrow(combdf[!is.na(combdf$controlle) & combdf$controlle==FALSE & combdf$sim<=0.7,])))
      colnames(percentages) <- c("perc", "false_pos", "false_neg", "true_pos", "true_neg")
      rownames(percentages) <- toString(0.7)
      for(perc in seq(from=.71, to=.95, by=.01)){
        per_teller <- data.frame(perc,
                                 c(nrow(combdf[!is.na(combdf$controlle) & combdf$controlle==FALSE & combdf$sim>perc,])),
                                 data.frame(nrow(combdf[!is.na(combdf$controlle) & combdf$controlle==TRUE & combdf$sim<perc,])),
                                 c(nrow(combdf[!is.na(combdf$controlle) & combdf$controlle==TRUE & combdf$sim>=perc,])),
                                 data.frame(nrow(combdf[!is.na(combdf$controlle) & combdf$controlle==FALSE & combdf$sim<=perc,])))
        colnames(per_teller) <- c("perc", "false_pos", "false_neg", "true_pos", "true_neg")
        rownames(per_teller) <- toString(perc)
        percentages <- rbind(percentages, per_teller)
      }

      percentages["totaal_fal"] <- (percentages$false_pos + percentages$false_neg)
      percentages["totaal_tru"] <- (percentages$true_pos + percentages$true_neg)
      percentages["false positive rate"] <- (percentages$false_pos / (percentages$false_pos+percentages$true_neg))
      percentages["false negative rate"] <- (percentages$false_neg / (percentages$false_neg+percentages$true_pos))
      percentages["sensitivity"] <- (percentages$true_pos / (percentages$true_pos+percentages$false_neg))
      percentages["specificity"] <- (percentages$true_neg / (percentages$true_neg+percentages$false_pos))
      return(percentages)
    } else{stop("Doe eerst tel_aantal_per_woord of zuiver_maken_met_woordenboek als u gekozen heeft voor onbegrensd bij de opmerking_split functie.")}
  } else{stop("Doe eerst tel_aantal_per_woord of zuiver_maken_met_woordenboek als u gekozen heeft voor onbegrensd bij de opmerking_split functie.")}
}

#Bundelen_voor_uitslagen#########################################################################################################
#' samenvoegen_opmerking_objectief
#'
#' @description Deze functie koppeld 2 outputs tot 1 output.
#' De selectie gaat op k.nummers. Zodra er een k.nummer niet in de objectieve waarden voorkomt wordt deze opgevuld door NA.
#'
#' @param tabelopm data.frame(): output zuiver_maken_met_woordenboek of output tel_aantal_per_woord of output samenvoegen_onderzoeksdata_ouders.
#' @param tabelgem data.frame(): output objectieve_waarden_gem.
#'
#' @return data.frame(): gekoppelde output.
#' @export
samenvoegen_opmerking_objectief <- function(tabelopm, tabelgem){
  samen <- try(
    if((class(tabelopm)[2] == "data_met_ouders" | class(tabelopm)[2] == "schoonmaak_per_key" | class(tabelopm)[2] == "tel_aantal_per_woord_per_key") & class(tabelgem)[2] == "objectieve_waarden_gem"){
      mer_tabel <- merge(tabelopm, tabelgem, by.x = "k.nummer", by.y = "k.nummer", all.x = T)
      class(mer_tabel) <- c("data.frame", "data_met_obj")
      return(mer_tabel)
    }, silent = TRUE)
  if("try-error" %in% class(samen)){
    stop(paste(deparse(substitute(tabelopm)), " of ", deparse(substitute(tabelgem)), " mist de juiste input gebruik eerst de functies zuiver_maken_met_woordenboek en objectieve_waarden_gem", sep = "" ))}
}

#' samenvoegen_onderzoeksdata_ouders
#'
#' @description Deze functie koppeld 2 outputs tot 1 output.
#' De selectie gaat op k.nummers. Zodra er een k.nummer niet in de tabelouder waarden voorkomt wordt deze opgevuld door NA.
#'
#' @param tabelopm  data.frame(): output samenvoegen_opmerking_objectief, output zuiver_maken_met_woordenboek of output tel_aantal_per_woord.
#' @param tabelouder data.frame(): Df dat uit minimaal twee kolommen bestaat, waarbij een kolom k.nummer moet heten.
#'
#' @return data.frame(): gekoppelde output.
#' @export
samenvoegen_onderzoeksdata_ouders <- function(tabelopm, tabelouder){

    samen <- try(
      if(class(tabelopm)[2] == "data_met_obj" | class(tabelopm)[2] == "schoonmaak_per_key" | class(tabelopm)[2] == "tel_aantal_per_woord_per_key"){
        mer_tabel <- merge(tabelopm, tabelouder, by.x = "k.nummer", by.y = "k.nummer", all.x = T)
        class(mer_tabel) <- c("data.frame", "data_met_ouders")
        return(mer_tabel)
      }, silent = TRUE)
  if("try-error" %in% class(samen)){
    stop(paste(deparse(substitute(tabelopm)), " mist de juiste input gebruik kijk in help voor meer informatie.", sep = "" ))}
}


#' keuze_woorden_voor_analyse
#'
#' @description Deze functie geeft u de mogelijkheid specifieke woorden aan te geven die u wilt analyseren.
#'  k.nummers die niet voldoen aan de ingevoerde specifieke woorden krijgen het woord 'geen'.
#'  Tevens zal er een extra kolom gemaakt worden genaamd 'dummie' hierin staan de getallen 1 t/m N waarbij N het aantal specifieke woorden is plus het woord 'geen'.
#'  Ieder specifiek woord zal zijn eigen getal krijgen. Indien bij input midden 'ja' is ingevoerd, wordt het woord 'geen' het middelste getal.
#'
#' @param tabel  data.frame(): output samenvoegen_opmerking_objectief of output samenvoegen_onderzoeksdata_ouders.
#' @param woorden  c(): Een of een serie woorden.
#' @param midden character('ja' of 'nee')
#'
#' @return data.frame(): Subselectie van input(tabel) op geanalayseerde woorden. Het kolom dummie zit hieraan vast.
#' @export
keuze_woorden_voor_analyse <- function(tabel, woorden, midden = "ja"){
  if(length(class(tabel))==2){
    if(class(tabel)[2] == "data_met_obj" | class(tabel)[2] == "schoonmaak_per_key" | class(tabel)[2] == "data_met_ouders"){
      if(is.character(woorden)){
        if(midden%in%c("ja","nee")){
          y <- 1
          weg_schrijven <- data.frame(tabel[tabel$opmerking==woorden[1],], "dummie" = y)
          geen <- tabel[tabel$opmerking%in%woorden,1]
          if(length(woorden)>1){
            for (woord in woorden[2:length(woorden)]){
              y <- y+1
              if(nrow(tabel[tabel$opmerking==woord,])>0){
                tijdelijk <- data.frame(tabel[tabel$opmerking==woord,], "dummie" = y)
                weg_schrijven <- rbind(weg_schrijven, tijdelijk)
              }
            }
          }
          y <- y+1
          tijdelijk <- tabel[!tabel$k.nummer%in%geen,]
          tijdelijk <- tijdelijk[!duplicated(tijdelijk[,1]),]
          tijdelijk["opmerking"] <- "geen"
          tijdelijk["Freq"] <- NA
          if(midden=="ja"){
            weg_schrijven$dummie <- ifelse(weg_schrijven$dummie>(length(woorden)/2), weg_schrijven$dummie+1, weg_schrijven$dummie)
            tijdelijk["dummie"] <- as.integer(length(woorden)/2)+1
          }else if(midden=="nee"){
            tijdelijk["dummie"] <- y
          }
          weg_schrijven <- rbind(weg_schrijven, tijdelijk)
          weg_schrijven <- weg_schrijven[order(weg_schrijven$dummie),]
          if(class(tabel)[2] == "data_met_ouders"){class(weg_schrijven) <- c("data.frame", "woorden_analyse", "data_met_ouders")}
          else{class(weg_schrijven) <- c("data.frame", "woorden_analyse")}
          return(weg_schrijven)
        }else(stop("Zorg er voor dat input midden of \"ja\" of \"nee\" is."))
      }else(stop("Zorg er voor dat u alleen een woorden in uw input 'woorden' stopt."))
    }else{stop("Doe eerst samenvoegen_onderzoeksdata_ouders of samenvoegen_opmerking_objectief om gebruik te maken van deze functie.")}
  }else{stop("Doe eerst samenvoegen_onderzoeksdata_ouders of samenvoegen_opmerking_objectief om gebruik te maken van deze functie.")}
}

#Deelvraag_1#########################################################################################################
#' Uitslag_verschillende_woorden
#'
#' @description Deze fuctie geeft een uitslag over de gemiddelde waarden, het aantal keer voorkomen en de correlatie tussen de veschillende woorden.
#' Ook zal hier een lijn-diagram van gemaakt worden.
#'
#' @param tabel  data.frame(): output keuze_woorden_voor_analyse
#' @param woorden  c(): Een of een serie woorden.
#'
#' @return list(data.frame, plot, cor.test): Een list waarin een df staat met de gemiddelde objectieve waarden per uniek woord en hoevaak dit woord voorkomt.
#' Verder staat er een lijn-diagram in met de objectieve waarden uitgezet.
#' Als laatste de uitslag van een correlatie test tussen de verschillende woorden.
#' @export
Uitslag_verschillende_woorden <- function(tabel, woorden="alles"){
  if(length(class(tabel))==2){
    if(class(tabel)[2] == "woorden_analyse"){
      weg_schrijven <- data.frame("woord" = NA, "gem_reactie" = NA, "aantal" = NA)
      if(woorden=="alles"){
        woorden <- unique(tabel$opmerking)
      }
      for (woord in woorden) {
        weg_schrijven[nrow(weg_schrijven) + 1,] <- c(woord, mean(tabel[(tabel$opmerking == woord) & !is.na(tabel$objectief),4]), nrow(tabel[tabel$opmerking == woord & !is.na(tabel$objectief),]))
      }
      weg_schrijven <- weg_schrijven[-1,]
      dummie_find <- sort(unique(tabel[tabel$opmerking%in%weg_schrijven$woord,"dummie"]))
      weg_schrijven <- list(weg_schrijven)
      plot(sort(unique(tabel[tabel$dummie%in%dummie_find,"dummie"])),
           aggregate(tabel[!is.na(tabel$objectief) & tabel$dummie%in%dummie_find,4],
                     list(tabel[!is.na(tabel$objectief) & tabel$dummie%in%dummie_find,"dummie"]), mean)[,2],
           ylab = "", xlab = "", main = "", xaxt = "n")
      axis(1, at=dummie_find, labels=unique(tabel[tabel$dummie%in%dummie_find,2]))
      weg_schrijven[["cor_test"]] <- (cor.test(tabel[tabel$dummie %in% c(dummie_find),4], tabel[tabel$dummie %in% c(dummie_find),"dummie"]))
      return(weg_schrijven)
    }else{stop("Doe eerst keuze_woorden_voor_analyse om gebruik te maken van deze functie.")}
  }else{stop("Doe eerst keuze_woorden_voor_analyse om gebruik te maken van deze functie.")}
}

#Deelvraag_2#########################################################################################################
#' Uitslag_per_los_woord
#'
#' @description Deze fuctie maakt twee diagrammen die voor 1 woord het aantal keer voorkomen uitzet tegen de objectieve waarden.
#'
#' @param tabel  data.frame(): output keuze_woorden_voor_analyse.
#' @param woord  character(): Een enkel woord die in uw opmerking kolom staat.
#'
#' @return plot(): Grafiek 1 laat de spreiding van k.nummers zien met hoevaak het ingevoerde woord voorkomt tegenover de objectieve waarden.
#' De tweede grafiek maakt hier een boxplot van met een trendlijn tussen het aantal keer voorkomen en de objectieve waarden.
#' @export
Uitslag_per_los_woord <- function(tabel, woord){
  if(length(class(tabel))==2){
    if(class(tabel)[2] == "woorden_analyse"){
      if(is.character(woord) & length(woord)==1){
        soort <- tabel[tabel$opmerking==as.character(woord) & !is.na(tabel[,4]),]
        gem <- aggregate(soort[,4], list(soort[,3]), mean)
        plot(tabel[tabel$opmerking==woord,3], tabel[tabel$opmerking==woord,4], ylab = "Objectief", xlab = paste("Aantal keer voorkomen van het woord " , as.character(woord)), main = "Spreiding reactietijd per N.")
        boxplot(tabel[tabel$opmerking==woord,4]~tabel[tabel$opmerking==woord,3], ylab = "Objectief", xlab = paste("Aantal keer voorkomen van het woord " , as.character(woord)), main = "Spreiding reactietijd per N.")
        abline(lm(tabel[tabel$opmerking==woord,4]~tabel[tabel$opmerking==woord,3]))
      }else{stop("Zorg er voor dat uw input bij woord, een enkel woord is omringt met \"\" ")}
    }else{stop("Doe eerst keuze_woorden_voor_analyse om gebruik te maken van deze functie.")}
  }else{stop("Doe eerst keuze_woorden_voor_analyse om gebruik te maken van deze functie.")}
}

#' uitslag_regressie
#'
#' @description Deze fuctie voert een lineaire regressie toets uit.
#'
#' @param tabel  data.frame(): output keuze_woorden_voor_analyse.
#'
#' @return summary(lm()): Uitslag over de objectieve waarden gebaseerd op de aangegeven kolommen.
#' @export
uitslag_regressie <- function(tabel){
  if(length(class(tabel))==2){
    if(class(tabel)[2] == "woorden_analyse"){
      limo <- summary(lm(objectief~ opmerking:Freq , data = tabel))
      return(limo)
    }else{stop("Doe eerst keuze_woorden_voor_analyse om gebruik te maken van deze functie.")}
  }else{stop("Doe eerst keuze_woorden_voor_analyse om gebruik te maken van deze functie.")}
}

#Deelvraag_3#########################################################################################################
#' uitslag_overerving
#'
#' @description Deze fuctie geeft een uitslag over de gemiddelde waarden, standaardafwijking en lineaire regressie toest gebaseerd op gebruikte woorden van de ouders van de k.nummer.
#' ook zullen de gemiddelde waarden en standaardafwijking in een grafiek uitgezet worden.
#'
#' @param tabel  data.frame(): output keuze_woorden_voor_analyse als u ook gebruik heeft gemaakt van samenvoegen_onderzoeksdata_ouders functie.
#' @param woorden  c(): Een of een serie woorden.
#'
#' @return list(data.frame, summary(lm()), plot): Een list waarin een df staat met de gemiddelde objectieve waarden en hun standaardafwijking per uniek woord-combinatie van beide ouders.
#' Verder staat er een uitslag over de objectieve waarden en ingevoerde woorden gebaseerd op de ouders.
#' Als laatste staat er een grafiek in waarbij de gemiddelde waarden en standaardafwijking zijn uitgezet per combinatie woorden van beide ouders.
#' @export
uitslag_overerving <- function(tabel, woorden=NULL){
  if(length(class(tabel))==3){
    if(class(tabel)[3] == "data_met_ouders"){
      if(is.null(woorden)){
        woorden <- unique(tabel$opmerking)
      } else(woorden <- woorden)
      tabel <- tabel[!duplicated(tabel[,1:2]),]
      tabel <- tabel[tabel$opmerking%in%woorden,]
      k.nummer <- aggregate(tabel[, 2], tabel[, c(1,4)], paste, collapse = ":")
      tabel <- tabel[!duplicated(tabel[,1]),]
      tabel <- merge(tabel, k.nummer, by.x = "Kloon.Pa", by.y = "k.nummer", all.x = T)
      tabel <- merge(tabel, k.nummer, by.x = "Kloon.Ma", by.y = "k.nummer", all.x = T)
      tabel <- tabel[,c(3,6,2,9,8,1,11,10)]
      names(tabel) <- c("k.nummer","k.objectief","pa.nummer","pa.woord","pa.objectief","ma.nummer","ma.woord","ma.objectief")
      tabel <- tabel[!is.na(tabel$pa.woord),]
      tabel <- tabel[!is.na(tabel$ma.woord),]
      uitslag <- summary(lm(k.objectief ~ pa.woord:pa.objectief:ma.woord:ma.objectief, data = tabel))
      uitslag <- list(uitslag)

      gemiddeld <- aggregate(tabel[!is.na(tabel[,2]),2], tabel[!is.na(tabel[,2]),c(4,7)], mean)
      standaarddef <- aggregate(tabel[!is.na(tabel[,2]),2], tabel[!is.na(tabel[,2]),c(4,7)], sd)
      gem_sdef <- cbind(gemiddeld, standaarddef[,3])
      names(gem_sdef) <- c("pa.woord", "ma.woord","gemiddelde","standaardafwijking")
      uitslag[[""]] <- gem_sdef

      uitslag[[""]] <- ggplot2::ggplot(gem_sdef, ggplot2::aes(x=paste(pa.woord, ma.woord, sep = ":"), y=gemiddelde)) +
        ggplot2::geom_errorbar(ggplot2::aes(ymin=gemiddelde-standaardafwijking, ymax=gemiddelde+standaardafwijking), width=.2) +
        ggplot2::geom_point() +
        ggplot2::labs(x = "", y = "Reactietijd") +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 90))
      return(uitslag)
    }else{"Voor deze functie moet u zowel de functie samenvoegen_onderzoeksdata_ouders gebruikt hebben even als functie keuze_woorden_voor_analyse."}
  }else{"Voor deze functie moet u zowel de functie samenvoegen_onderzoeksdata_ouders gebruikt hebben even als functie keuze_woorden_voor_analyse."}
}
