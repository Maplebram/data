#' Hoofddataset voor bijna alle functies uitvoeren.
#'
#' @description Hoofddataset, met het gebruik van kloonnummer en opmerking kun je bijna alle functies uitvoeren.
#'
#' @source Deze dataset is verschaft door het bedrijf Deliflor.
#' @format Een dataframe met 297746 regels en 11 kolommen:
#' \describe{
#'  \item{Kloonnummer}{Getal tussen de 1 en de 4002790 de k.nummmer(sleutel) waar alles mee gerefereerd  mee wordt.}
#'  \item{Opmerking}{Gegevens van belang, Factor met allelij teksten per regel. Dit kan zo kort zijn als leeg tot meerdere woorden achter elkaar.}
#'  \item{Jaar}{Jaartallen tussen de 1998 en 2019 dat indiceert wanneer de bloeiproef is uitgevoerd.}
#'  \item{Locatie}{De locatie waar de bloeiproef van deze data is uitgevoerd. Dit is of KKD of NWW.}
#'  \item{Bloeiproefnummer}{Getal tussen de 20 en 19259 dat aangeeft over welke bloeiproef is uitgevoerd dat jaar.}
#'  \item{Veld}{Getal tussen de 0 en 999 dat aangeeft op welk veld de bloeiproef was uitgevoerd.}
#'  \item{Beoordeling}{Het getal 1. Een vereiste om de specifieke data uit de database te halen van deliflor.}
#'  \item{PNH}{Beoordeling van de veredelaars, hoe goed zij de specifieke chrysant tijdens de specifieke bloeiproef vonden. P = positief, N= negatief, H = houden en . = niet ingevuld.}
#'  \item{Gebruik.NL}{Mede met met Doelgroep en Bloemtype geeft dit aan wat voor specifieke chrysant de kloonnummer is op deze regel.}
#'  \item{Doelgroep}{Mede met met Gebruik.nl en Bloemtype geeft dit aan wat voor specifieke chrysant de kloonnummer is op deze regel.}
#'  \item{Bloemtype}{Mede met met Gebruik.nl en Doelgroep geeft dit aan wat voor specifieke chrysant de kloonnummer is op deze regel.}
#' }
#' @examples
#' \dontrun{
#'  kloon_met_hun_opmerkingen
#' }
"kloon_met_hun_opmerkingen"



#' Dataset gebaseerd op objectieve waarden van de chrysanten.
#'
#' @description Deze dataset is nodig voor de functies objectieve_waarden_gem, samenvoegen_opmerking_objectief en keuze_woorden_voor_analyse en de uitslag functies uitslag_overerving, Uitslag_per_los_woord, Uitslag_verschillende_woorden en uitslag_regressie
#'
#' @source Deze dataset is verschaft door het bedrijf Deliflor.
#' @format Een dataframe met 264029 regels en 6 kolommen:
#' \describe{
#'  \item{Kloonnummer}{Getal tussen de 1 en de 6001023 de k.nummmer(sleutel) waar alles mee gerefereerd  mee wordt.}
#'  \item{Reactietijd}{Getal tussen de 6 en de 82 dat aangeeft hoe snel de chrysant heeft gegroeid tijdens een specifieke bloeiproef. Lager is sneller.}
#'  \item{Takgewicht}{Getal tussen de 0 en de 8095 dat aangeeft hoe zwaar de chrysant is geweest in een specifieke bloeiproef.}
#'  \item{Lengte}{Getal tussen de 0 en de 319 dat aangeeft hoe lang de chrysant is geweest in een specifieke bloeiproef.}
#'  \item{Aantal.bloemen}{Getal tussen de 0 en 5099 dat aangeeft hoeveel bloemen er op de chrysant geteld zijn tijdens een specifieke bloeiproef.}
#'  \item{Bladlengte}{Getal tussen de 0 en 23 dat aangeeft hoe land de gemiddelde bladlengte is geweest tijdens een specifieke bloeiproef.}
#' }
#' @examples
#' \dontrun{
#'  kloon_met_objectieve_waarden
#' }
"kloon_met_objectieve_waarden"

#' Dataset dat eer relatie maakt tussen kloonnmmer onderling. Als ouders van kinderen.
#'
#' @description Sample nodig voor de functies samenvoegen_onderzoeksdata_ouders en uitslag_overerving.
#'
#' @source Deze dataset is verschaft door het bedrijf Deliflor.
#' @format Een dataframe met 62905 regels en 6 kolommen:
#' \describe{
#'  \item{Kloonnummer}{Getal tussen de 1 en de 101299 de k.nummmer(sleutel) waar alles mee gerefereerd  mee wordt.}
#'  \item{Populatiejaar}{Jaartallen tussen de 0 en 2019. Mede met Populatie geeft dit de relatie aan tussen ouders en kind.}
#'  \item{Populatie}{Factor met getallen en woorden. Mede met Populatiejaar geeft dit de relatie aan tussen ouders en kind.}
#'  \item{Kloon.Pa}{Kloonnummer tussen de 20 en 100610 dat dient als ouder voor de kloonnummer op dezelfde regel.}
#'  \item{Kloon.Ma}{Kloonnummer tussen de 20 en 100610 dat dient als ouder voor de kloonnummer op dezelfde regel.}
#'  \item{Specie}{'chr' voor chrysant. Een vereiste om de specifieke data uit de database te halen van deliflor.}
#' }
#' @examples
#' \dontrun{
#'  kloon_met_ouders
#' }
"kloon_met_ouders"

#' Default woordenboek voor deze package.
#'
#' @description Deze package maakt gebruik van een woordenboek. Indien deze niet wordt toegevoegd in de functies, zal deze dataset gebruikt worden.
#'
#' @source Deze dataset is verschaft door het bedrijf Deliflor.
#' @format Een dataframe met 635 regels and 2 kolommen:
#' \describe{
#'  \item{fout_w}{Factor met woorden die foutief zijn. Als deze woorden in de data gevonden worden zal hij het veranderen in het woord in kolom goed_w}
#'  \item{goed_w}{Factor met woorden die goed zijn. Afhankelijk van de zuiverheid van de data zullen woorden gaan lijken op de woorden in deze kolom.}
#' }
#' @examples
#' \dontrun{
#'  sample_woordenboek
#' }
"sample_woordenboek"
